-- AlterTable
ALTER TABLE "AuditLog" ALTER COLUMN "entityId" SET DATA TYPE TEXT;
